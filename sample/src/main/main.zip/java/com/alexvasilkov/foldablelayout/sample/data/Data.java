package com.alexvasilkov.foldablelayout.sample.data;

public class Data {
    static User user;
    static void login(){

    }
}
